package ddd;

public class SimEngine {
	private double m; // masa
	private double k; // wspolczynnik sprezystosci
	private double C; // tlumienie
	private double L; // dlugosc swobodna sprezyny
	private Vector2D x; // polozenie masy
	private Vector2D v;//predkosc masy
	private Vector2D xz; //polozenie punktu zawieszenia
	private double g; //przyspieszenie grawitacyjne
	double t=0;//czas
	
	//konstruktor z parametrami
	public SimEngine(double m, double k, double C, double L, Vector2D x, Vector2D v, Vector2D xz, double g){
		//kontrola wartosci (ternary operator), jesli wartosc<0, przypisana wartosc=0
		this.m= m>0 ? m : 0;
		this.k= k>0 ? k : 0;
		this.C= C>0 ? C : 0;
		this.L= L>0 ? L : 0;
		this.x=x;
		this.v=v;
		this.xz=xz;
		this.g=g;	
	}
	//akcesory
	public double getM(){return m;}
	public double getK(){return k;}
	public double getC(){return C;}
	public double getL(){return L;}
	public Vector2D getX(){return x;}
	public Vector2D getV(){return v;}
	public Vector2D getXZ(){return xz;}
	public double getG(){return g;}
	//mutatory
	public void setM(double m){this.m=m;}
	public void setK(double k){this.k=k;}
	public void setC(double C){this.C=C;}
	public void setL(double L){this.L=L;}
	public void setX(Vector2D wektor){this.x.x=wektor.x;this.x.y=wektor.y;}
	public void setV(Vector2D wektor){this.v.x=wektor.x;this.v.y=wektor.y;}
	public void setXZ(Vector2D wektor){this.xz.x=wektor.x;this.xz.y=wektor.y;}
	public void setG(double g){this.g=g;}
	
	// deklaracje sil
	private Vector2D f=new Vector2D();
	private Vector2D fG=new Vector2D();
	private Vector2D fK=new Vector2D();
	private Vector2D fC=new Vector2D();
	//akcesory sil
	public Vector2D getF(){return f;}
	public Vector2D getFG(){return fG;}
	public Vector2D getFK(){return fK;}
	public Vector2D getFC(){return fC;}
	
	//metoda obliczajaca przebieg symulacji
	public void calc(double krok_czasowy){
		//definicje sil
		fG= new Vector2D(0,m*g);
		fK=getXZ().roznica(getX()).normalizacja().iloczyn(k*(x.roznica(xz).modul()- L));
		fC=v.iloczyn(-C);
		f=fG.suma(fK).suma(fC);
		//odbicie od utwierdzenia
		if(x.y<=xz.y){
			v.y=-1*v.y;
		}
		
		t+=krok_czasowy;
		v=v.suma(f.iloczyn(krok_czasowy/m));
		x=x.suma(v.iloczyn(krok_czasowy));

		//System.out.println("Czas: " + t);
		//System.out.println("Predkosc" + v.modul());	
	}
	
	//metoda resetujaca symulacje
	public void reset(){
		v.x=0;
		v.y=0;
	}
}