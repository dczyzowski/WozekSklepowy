package ddd;

public class SimTask extends java.util.TimerTask{
	//deklaracja pol prywatnych
	private SimEngine simEngine;
	private SpringApplet springApplet;
	double krok_czasowy;
	
	//konstruktor z parametrami
	public SimTask(SimEngine simEngine, SpringApplet springApplet, double krok_czasowy){
		this.simEngine=simEngine;
		this.springApplet=springApplet;
		this.krok_czasowy=krok_czasowy;		
	}
	
	public double getT(){return krok_czasowy;}
	public void setT(double krok_czasowy){this.krok_czasowy=krok_czasowy;}
	
	//przesloniecie metody abstrakcyjnej run
	public void run(){
		simEngine.calc(this.getT());
		springApplet.repaint();
	}	
}