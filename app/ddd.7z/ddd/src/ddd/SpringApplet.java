package ddd;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import java.util.Timer;

public class SpringApplet extends javax.swing.JApplet implements MouseListener, MouseMotionListener, ActionListener, Runnable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2019202801065251325L;
	//deklaracja pol prywatnych
	private SimTask simTask;
	private SimEngine simEngine;
	private Timer timer;
	Date currentDate = new Date();
	//definicja promienia masy (kula)
	int promien=40;
	//deklaracja wartosci logicznej przechowujacej stan myszy
	private boolean mouseDragging;
	//deklaracja pol tekstowych
	TextField m, k, c, l, g, tF;
	//deklaracja przycisku reset
	Button reset;
	double getX, getY;
	//polozenie startowe wektora X
	double xX=340;
	double yY=180;
	Label mL, kL, cL, lL, gL, tL;
	
	@Override
	public void init() {

	currentDate.setTime(0);
	Vector2D xz = new Vector2D(475, 30);
	Vector2D x = new Vector2D(xX, yY);
	Vector2D v = new Vector2D(0, 0);
	simEngine = new SimEngine(5, 100, 1, 400, x, v, xz, 10);
	timer = new Timer();
	simTask = new SimTask(simEngine, this, 0.001);
	timer.scheduleAtFixedRate(simTask, currentDate.getTime(), 1);
	//inicjalizacja pola przechowujacego stan myszy
	mouseDragging=false;
	addMouseListener(this);
	addMouseMotionListener(this);
	
	//inicjalizacja przycisku RESET
	reset = new Button ("RESET");
	//inicjalizacja pozostalych pol tekstowych
	m = new TextField(String.valueOf(simEngine.getM()));
	k = new TextField(String.valueOf(simEngine.getK()));
	c = new TextField(String.valueOf(simEngine.getC()));
	l = new TextField(String.valueOf(simEngine.getL()));
	g = new TextField(String.valueOf(simEngine.getG()));
	tF = new TextField(String.valueOf(simTask.getT()));
	mL= new Label("Masa:");
	kL= new Label("Wsp. sprezystosci:");
	cL= new Label("Tlumienie:");
	lL= new Label("Dlugosc swobodna:");
	gL= new Label("Grawitacja:");
	tL= new Label("Tempo:");
	reset.setBackground(Color.RED);
	
	//dodawanie elementow do apletu (dodawane od lewej zgodnie z kolejnoscia)
	add(mL);
	add(m);
	add(kL);
	add(k);
	add(cL);
	add(c);
	add(lL);
	add(l);
	add(gL);
	add(g);
	add(tL);
	add(tF);
	add(reset);
	reset.addActionListener(this);
	
	this.setSize(900, 600);
	setLayout(new FlowLayout(FlowLayout.LEFT));
	setVisible(true);
	}
	
	//w celu wyeliminowania migania obrazu zastosowane zostalo podwojne buforowanie	
	//obiekt abstrakcyjnej klasy Image
	private Image i;
	//obiekt ktory posluzy za dodatkowy bufor
	private Graphics bufor;
	
	@Override
	public void paint(Graphics g) {
		//tworzenie obrazu poza ekranem (jest to kopia obrazu wyswietlanego na aplecie), ktory uzyty zostanie do podwojnego buforowania
		i=createImage(this.getWidth(), this.getHeight());
		//tworzenie kopii grafiki poza ekranem i zapisanie jej do obiektu bufor
		bufor= i.getGraphics();
		//wyrysowanie grafiki w obszarze apleta
		paintComponent(bufor);
		//wyrysowanie obrazu
		g.drawImage(i, 0, 0, this);
	}
		
	public void paintComponent(Graphics g) {
		//ustawienie rozmiaru appletu
		this.setSize(950, 700);

		//zapisanie rozmiaru appletu do zmiennej d
		Dimension d = getSize();
		
		//okreslenie koloru tla
		g.setColor(getBackground());
		setBackground(Color.BLACK);
		g.fillRect(0, 0, d.width, d.height);
		
		//naniesienie siatki wspolrzednych
		for(int i=0; i<d.width; ){
			g.setColor(Color.DARK_GRAY);
			g.drawLine(i, 0, i, d.height);
			i+=10;
		}
		for(int i=0; i<d.height; ){
			g.setColor(Color.DARK_GRAY);
			g.drawLine(0, i, d.width, i);
			i+=10;
		}
		
		g.setColor(Color.WHITE);
		
		//liczba zwojow sprezyny
		double z=80;
		//tangens kata potrzebny do rysowania sprezyny
		double tan= (simEngine.getX().y-simEngine.getXZ().y)/(simEngine.getX().x-simEngine.getXZ().x);
		//rysowanie sprezyny
		for(int i=0; i<z; i++){
			if(i!=0 && i!=z-1){
			g.drawLine((int) simEngine.getXZ().x + (int) ((simEngine.getXZ().y+ i*((simEngine.getX().y- simEngine.getXZ().y)/z)-simEngine.getXZ().y)/tan) +10,(int) (simEngine.getXZ().y+ i*((simEngine.getX().y- simEngine.getXZ().y)/z)), (int) simEngine.getXZ().x + (int) ((simEngine.getXZ().y+ (i+1)* ((simEngine.getX().y- simEngine.getXZ().y)/z)-simEngine.getXZ().y)/tan)-10, (int) (simEngine.getXZ().y+ (i+1)* ((simEngine.getX().y- simEngine.getXZ().y)/z)));
			g.drawLine((int) simEngine.getXZ().x + (int) ((simEngine.getXZ().y+ (i+1)*((simEngine.getX().y- simEngine.getXZ().y)/z)-simEngine.getXZ().y)/tan)-10, (int) (simEngine.getXZ().y+ (i+1)*((simEngine.getX().y- simEngine.getXZ().y)/z)), (int) simEngine.getXZ().x +  (int) ((simEngine.getXZ().y+ (i+1)*((simEngine.getX().y- simEngine.getXZ().y)/z)-simEngine.getXZ().y)/tan)+10, (int) (simEngine.getXZ().y+ (i+1)*((simEngine.getX().y- simEngine.getXZ().y)/z)));
			}
			else if(i==0){
			g.drawLine((int) simEngine.getXZ().x, (int) (simEngine.getXZ().y+ i*((simEngine.getX().y- simEngine.getXZ().y)/z)), (int) simEngine.getXZ().x + (int) ((simEngine.getXZ().y+ (i+1)* ((simEngine.getX().y- simEngine.getXZ().y)/z)-simEngine.getXZ().y)/tan)-10, (int) (simEngine.getXZ().y+ (i+1)* ((simEngine.getX().y- simEngine.getXZ().y)/z)));
			g.drawLine((int) simEngine.getXZ().x + (int) ((simEngine.getXZ().y+ (i+1)*((simEngine.getX().y- simEngine.getXZ().y)/z)-simEngine.getXZ().y)/tan)-10, (int) (simEngine.getXZ().y+ (i+1)*((simEngine.getX().y- simEngine.getXZ().y)/z)), (int) simEngine.getXZ().x +  (int) ((simEngine.getXZ().y+ (i+1)*((simEngine.getX().y- simEngine.getXZ().y)/z)-simEngine.getXZ().y)/tan)+10, (int) (simEngine.getXZ().y+ (i+1)*((simEngine.getX().y- simEngine.getXZ().y)/z)));
			}
			else{
			g.drawLine((int) simEngine.getXZ().x + (int) ((simEngine.getXZ().y+ i*((simEngine.getX().y- simEngine.getXZ().y)/z)-simEngine.getXZ().y)/tan) +10,(int) (simEngine.getXZ().y+ i*((simEngine.getX().y- simEngine.getXZ().y)/z)), (int) simEngine.getXZ().x + (int) ((simEngine.getXZ().y+ (i+1)* ((simEngine.getX().y- simEngine.getXZ().y)/z)-simEngine.getXZ().y)/tan), (int) (simEngine.getXZ().y+ (i+1)* ((simEngine.getX().y- simEngine.getXZ().y)/z)));
			}
		}
		
		//utwierdzenie masy- linia prosta i kreskowanie
		g.drawLine( 0, (int) simEngine.getXZ().y, d.width, (int) simEngine.getXZ().y);
		for (int i=0; i<d.width; i+=(d.width)/80){
			g.drawLine(i, (int) simEngine.getXZ().y, i+(d.width)/80, 0);
		}
		
		//rysowanie masy
		g.drawOval((int) simEngine.getX().x- promien, (int) simEngine.getX().y, 2*promien, 2*promien);
		//wypisaine czasu 
		g.drawString("Czas: "  + simEngine.t/1000 + "s.", 10, 50);
		
		//wysokosc grotu wektora
		int grot=15;
		//tablica zawierajaca wektory, ktore nastepnie beda rysowane
		Vector2D[] wektory= {simEngine.getF(), simEngine.getFK(), simEngine.getFC(), simEngine.getFG(), simEngine.getV()};
		//tablica zawierajaca kolory wektorow
		Color[] kolory= {Color.red, Color.blue, Color.magenta, Color.green, Color.yellow};
		//rysowanie wektorow
		for(int i=0; i<wektory.length; i++){
			
			g.setColor(kolory[i]);
			//kat rozwarcia grotow
			double alfa=15;
			
			//wartosci uzywane do okreslenia polozenia grotow wektorow
			double x1prim= Math.cos(Math.toRadians(alfa))*Math.abs(wektory[i].normalizacja().iloczyn(grot).x)- Math.sin(Math.toRadians(alfa))*Math.abs(wektory[i].normalizacja().iloczyn(grot).y);
			double y1prim= Math.sin(Math.toRadians(alfa))*Math.abs(wektory[i].normalizacja().iloczyn(grot).x)+ Math.cos(Math.toRadians(alfa))*Math.abs(wektory[i].normalizacja().iloczyn(grot).y);
			double x2prim= Math.cos(Math.toRadians(-alfa))*Math.abs(wektory[i].normalizacja().iloczyn(grot).x)- Math.sin(Math.toRadians(-alfa))*Math.abs(wektory[i].normalizacja().iloczyn(grot).y);
			double y2prim= Math.sin(Math.toRadians(-alfa))*Math.abs(wektory[i].normalizacja().iloczyn(grot).x)+ Math.cos(Math.toRadians(-alfa))*Math.abs(wektory[i].normalizacja().iloczyn(grot).y);
			
			g.drawLine((int) simEngine.getX().x, (int) simEngine.getX().y+ promien, (int) simEngine.getX().x+ (int) wektory[i].x, (int) simEngine.getX().y+ (int) wektory[i].y+ promien);
			//warunek if stworzony w celu okreslenia zwrotu wektora (wskazanie grota strzalki)
			if(wektory[i].y>=0 && wektory[i].x<=0){
			g.drawLine((int) simEngine.getX().x+ (int) wektory[i].x, (int) simEngine.getX().y+ (int) wektory[i].y+ promien, (int) simEngine.getX().x+ (int) wektory[i].x +(int)x1prim, (int) simEngine.getX().y+ (int) wektory[i].y+ promien - (int) y1prim);
			g.drawLine((int) simEngine.getX().x+ (int) wektory[i].x, (int) simEngine.getX().y+ (int) wektory[i].y+ promien, (int) simEngine.getX().x+ (int) wektory[i].x +(int)x2prim, (int) simEngine.getX().y+ (int) wektory[i].y+ promien - (int) y2prim);
			}else if(wektory[i].y<=0 && wektory[i].x>=0){
			g.drawLine((int) simEngine.getX().x+ (int) wektory[i].x, (int) simEngine.getX().y+ (int) wektory[i].y+ promien, (int) simEngine.getX().x+ (int) wektory[i].x -(int)x1prim, (int) simEngine.getX().y+ (int) wektory[i].y+ promien + (int) y1prim);
			g.drawLine((int) simEngine.getX().x+ (int) wektory[i].x, (int) simEngine.getX().y+ (int) wektory[i].y+ promien, (int) simEngine.getX().x+ (int) wektory[i].x -(int)x2prim, (int) simEngine.getX().y+ (int) wektory[i].y+ promien + (int) y2prim);
			}else if(wektory[i].y>=0 && wektory[i].x>=0){
			g.drawLine((int) simEngine.getX().x+ (int) wektory[i].x, (int) simEngine.getX().y+ (int) wektory[i].y+ promien, (int) simEngine.getX().x+ (int) wektory[i].x -(int)x1prim, (int) simEngine.getX().y+ (int) wektory[i].y+ promien - (int) y1prim);
			g.drawLine((int) simEngine.getX().x+ (int) wektory[i].x, (int) simEngine.getX().y+ (int) wektory[i].y+ promien, (int) simEngine.getX().x+ (int) wektory[i].x -(int)x2prim, (int) simEngine.getX().y+ (int) wektory[i].y+ promien - (int) y2prim);
			}else if(wektory[i].y<=0 && wektory[i].x<=0){
			g.drawLine((int) simEngine.getX().x+ (int) wektory[i].x, (int) simEngine.getX().y+ (int) wektory[i].y+ promien, (int) simEngine.getX().x+ (int) wektory[i].x +(int)x1prim, (int) simEngine.getX().y+ (int) wektory[i].y+ promien + (int) y1prim);
			g.drawLine((int) simEngine.getX().x+ (int) wektory[i].x, (int) simEngine.getX().y+ (int) wektory[i].y+ promien, (int) simEngine.getX().x+ (int) wektory[i].x +(int)x2prim, (int) simEngine.getX().y+ (int) wektory[i].y+ promien + (int) y2prim);
			}
	}
}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == reset) {
			timer.cancel();
			Vector2D nowyWektor= new Vector2D(xX,yY);
			//resetowanie predkosci
			simEngine.reset();
			//inicjalizacja nowych wartosci obiektu simEngine
			simEngine.setX(nowyWektor);
			simEngine.setM(Double.parseDouble(m.getText()));
			simEngine.setG(Double.parseDouble(g.getText()));
			simEngine.setK(Double.parseDouble(k.getText()));
			simEngine.setC(Double.parseDouble(c.getText()));
			simEngine.setL(Double.parseDouble(l.getText()));
			simTask.setT(Double.parseDouble(tF.getText()));
			simEngine.t=0;
			this.repaint();
		}
	}
	
	@Override
	public void mouseDragged(MouseEvent e) {
		if (mouseDragging == true) {
			//ustawienie pozycji masy obiektu simEngine zgodnie z pozycja kursora
			simEngine.getX().x = e.getX();
			simEngine.getX().y = e.getY();
			this.repaint();
			e.consume();
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		//odczytanie pozycji kursora
		getX = e.getX();
		getY = e.getY();
		//warunek na to czy pozycja kursora znajduje sie w obrebie powierzchni masy
		if ((getX -simEngine.getX().x)*(getX -simEngine.getX().x)+ (getY- simEngine.getX().y-promien)*(getY- simEngine.getX().y-promien) <= promien*promien) {
			simTask.cancel();
			simEngine.reset();
			mouseDragging = true;
			e.consume();
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (mouseDragging == true) {
			Timer newTimer = new Timer();
			simTask = new SimTask(simEngine, this, simTask.getT());
			newTimer.scheduleAtFixedRate(simTask, currentDate.getTime(), 1);
			mouseDragging = false;
			e.consume();
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {		
	}

	@Override
	public void mouseClicked(MouseEvent e) {		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}