package ddd;

public class Vector2D {
	//publiczne pola wspolrzednych wektora
	public double x, y;
	
	//Konstruktor domyslny
	public Vector2D(){
		x=0;
		y=0;
	}
	//Konstruktor z parametrem
	public Vector2D(double x, double y){
		this.x=x;
		this.y=y;
	}
	//Suma
	public Vector2D suma(Vector2D skladnik){
		double sx=x+skladnik.x;
		double sy=y+skladnik.y;
		Vector2D suma= new Vector2D(sx, sy);
		return suma;		
	}
	//Roznica
	public Vector2D roznica(Vector2D odjemnik){
		double rx=x-odjemnik.x;
		double ry=y-odjemnik.y;
		Vector2D roznica= new Vector2D(rx, ry);
		return roznica;		
	}
	//Mnozenie
	public Vector2D iloczyn(double mnoznik){
		double ix=x*mnoznik;
		double iy=y*mnoznik;
		Vector2D iloczyn= new Vector2D(ix,iy);
		return iloczyn;		
	}
	//Modul
	public double modul(){
		double modul= Math.sqrt(x*x+y*y);
		return modul;
	}
	//Metoda normalizujaca
	public Vector2D normalizacja(){
		Vector2D wersor = new Vector2D();
		wersor.x = x/modul();
		wersor.y = y/modul();
		return wersor;
	}
}